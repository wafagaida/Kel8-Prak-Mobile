import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class NewsDetailScreen extends StatefulWidget {
  const NewsDetailScreen({
    super.key,
    required this.id,
  });
  final String id;

  @override
  State<NewsDetailScreen> createState() => _NewsDetailScreenState();
}

class _NewsDetailScreenState extends State<NewsDetailScreen> {
  String desc =
      "ROG Phone 7 dan ROG Phone 7 Ultimate mengusung layar AMOLED berukuran 6,78 inch dengan resolusi Full HD+. Asus memberikan dukungan refresh rate 165 Hz, touch sampling rate 720 Hz, tingkat kecerahan 1.500 nits, dan tersertifikasi Pixelworks.Asus menyokong ROG Phone 7 dan 7 Ultimate dengan chipset Snapdragon 8 Gen 2 yang dipasangkan dengan RAM LPDDR5X hingga 16 GB dan memori internal UFS 4.0 sampai 512 GB. Racikan tersebut menjanjikan kinerja ngebut untuk bermain game berat.Agar main game lebih maksimal, Asus menyematkan GameCool 7 dan penyetelan khusus. Sistem pendingin GameCool 7 mampu mendinginkan CPU dari segala arah. Metode ini menggunakan pendekatan tiga cabang. Untuk sesi singkat, senyawa termal Boron Nitride (BN) di satu sisi CPU mengurangi pelambatan. Sesi tengah ditangani oleh vapor chamber yang lebih besar dan lembaran grafit di sisi lain CPU.";
  int likeCount = 0;
  void initState() {
    likeCount = 0;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          setState(() {
            likeCount++;
            print(likeCount);
          });
        },
        backgroundColor: Colors.red,
        child: Icon(Icons.favorite),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              IconButton(
                onPressed: () {
                  GoRouter.of(context).pop();
                },
                icon: const Icon(Icons.chevron_left_rounded),
              ),
              const Text("News Detail")
            ],
          ),
          Image.network(
            "https://akcdn.detik.net.id/community/media/visual/2023/04/14/asus-rog-phone-7-2.jpeg?w=1024",
          ),
          const SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      "Headline News",
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    Row(
                      children: [
                        Icon(
                          Icons.favorite,
                          color: Colors.red,
                          size: 25,
                        ),
                        SizedBox(
                          width: 8,
                        ),
                        Text(likeCount.toString())
                      ],
                    )
                  ],
                ),
                const Text(
                  "Source Image : Pexels.com",
                  style: TextStyle(fontSize: 14, fontStyle: FontStyle.italic),
                ),
                Text(
                  desc,
                  style: const TextStyle(fontSize: 10),
                  textAlign: TextAlign.justify,
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}
