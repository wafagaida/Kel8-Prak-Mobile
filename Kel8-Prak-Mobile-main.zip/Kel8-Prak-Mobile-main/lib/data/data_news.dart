import '../models/news.dart';

List<News> newslist = [
  News(
      id: 12345,
      deskripsi:
          "Jakarta, CNN Indonesia -- Setelah pemilik akun TikTok Awbimax Reborn, Bima Yudho Saputro mengaku keluarganya mendapat ancaman dan intimidasi, Polres Lampung Timur dan Kapolsek Raman Utara mendatangi dan bersilaturahmi ke rumah orang tua Bima di Desa Ratna Daya, Kecamatan Raman Utara, Kabupaten Lampung Timur. Kedatangannya, lanjut Kapolres, disambut oleh kedua orangtua Bima yakni Juliman dan Sri Ngatun. Ayah dari Bima menyampaikan secara langsung bahwa informasi intimidasi yang diduga dilakukan anggota Polri dari Polres Lampung Timur itu tidak benar.",
      gambar: "asset/ilustrasi-aplikasi-tiktok-8_169.jpeg",
      judul:
          "Orang Tua TikToker Pengkritik Lampung Minta Maaf ke Gubernur Lampung"),
  News(
      id: 12435,
      deskripsi:
          "ROG Phone 7 dan ROG Phone 7 Ultimate mengusung layar AMOLED berukuran 6,78 inch dengan resolusi Full HD+. Asus memberikan dukungan refresh rate 165 Hz, touch sampling rate 720 Hz, tingkat kecerahan 1.500 nits, dan tersertifikasi Pixelworks.Asus menyokong ROG Phone 7 dan 7 Ultimate dengan chipset Snapdragon 8 Gen 2 yang dipasangkan dengan RAM LPDDR5X hingga 16 GB dan memori internal UFS 4.0 sampai 512 GB. Racikan tersebut menjanjikan kinerja ngebut untuk bermain game berat.Agar main game lebih maksimal, Asus menyematkan GameCool 7 dan penyetelan khusus. Sistem pendingin GameCool 7 mampu mendinginkan CPU dari segala arah. Metode ini menggunakan pendekatan tiga cabang. Untuk sesi singkat, senyawa termal Boron Nitride (BN) di satu sisi CPU mengurangi pelambatan. Sesi tengah ditangani oleh vapor chamber yang lebih besar dan lembaran grafit di sisi lain CPU.",
      gambar: "asus-rog-phone-7-2.jpeg",
      judul:
          "Asus ROG Phone 7 dan 7 Ultimate Dirilis, Segera Hadir di Indonesia"),
];
